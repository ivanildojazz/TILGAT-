
// Backend API (Node.js/Express)
const express = require('express');
const app = express();
app.use(express.json());

app.post('/webhook/bai', (req, res) => {
  const { amount } = req.body;
  if (amount < 100000 || amount > 20000000) {
    return res.status(400).json({ error: 'Valor fora dos limites (100.000 - 20.000.000 AOA)' });
  }
  return res.json({ success: true, message: 'Transferência recebida e validada', amount });
});

app.listen(3000, () => console.log('API TILGAT rodando na porta 3000'));
